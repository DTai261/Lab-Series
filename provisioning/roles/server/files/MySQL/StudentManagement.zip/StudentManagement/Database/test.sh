#!/bin/bash

echo "Restore default database successfully!"

mysql -u root --password=your_root_password student_management < Database/student_management.sql
# Add more commands as needed
