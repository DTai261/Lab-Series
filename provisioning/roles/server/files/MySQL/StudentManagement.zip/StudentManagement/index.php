<?
    session_start();

    if(!isset($_SESSION['role']) and !isset($_SESSION['username'])){
        header("Location: Login.php");
    }
    $fullname = $_SESSION['fullname'];
    $role = $_SESSION['role'];
	// var_dump($_SESSION);
?>

<!DOCTYPE html>
<html amp>
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo-1.png" type="image/x-icon">
  <meta name="description" content="New Startup AMP HTML Mobile App Template - Download Now">
  <title>Home Page</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- <link rel="canonical" href="index.html"> -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,500,600,700&subset=cyrillic" rel="stylesheet">
<link rel="stylesheet" href="css/index.css">

<style>
        body {
            position: relative;
        }
        
        .button-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
        }
    </style>
  
</head>
<body>
    
<amp-sidebar id="sidebar" class="cid-qPyhTAFa5u" layout="nodisplay" side="right"></amp-sidebar>
<section class="menu horizontal-menu cid-qPyhTAFa5u" id="menu1-b">
    <nav class="navbar navbar-dropdown  navbar-fixed-top  ">
        <div class="container">
            <div class="navbar-brand">
                <span class="navbar-caption-wrap">
                    <a class="navbar-caption text-white display-5" href="#">
                        <strong>HOD401</strong>
                    </a>
                </span>
            </div>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
                    <!-- <li class="nav-item">
                        <a class="nav-link link text-white display-7" href="test.php?>">
                            <strong>TEST</strong>
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link link text-white display-7" href="Profile.php?id=<?=$_SESSION['id']?>&ref=index.php">
                            <strong>PROFILE</strong>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link link text-white display-7" href="Signout.php">
                            <strong>SIGN OUT</strong>
                        </a>
                    </li>
            </div>
        </div>
    </nav>
</section><br><br>

<section class="features9 cid-qPmtM8eXNH" id="features9-9">

    
    

    <div class="container">

        <h1 class="mbr-fonts-style mbr-section-title2 display-2"><strong>Welcome </strong><?=htmlspecialchars($fullname)?> !</h1>
        <h3 class="mbr-fonts-style subtitle mbr-text display-4">Education is the key to success</h3>
        <div class="line-wrap">
            <div class="line"></div>
        </div>
        <div class="mbr-row mbr-justify-content-center">
<!-- =================================> https://fontawesome.com/v4/icons/ <=================================-->
            <div class="mbr-col-lg-6 mbr-col-md-10">
                <a href="ListStudents.php">
                    <div class="wrap">
                        <div class="ico-wrap">
                            <span class="mbr-iconfont fa-list-ol fa"></span>
                        </div>
                        <div class="text-wrap vcenter">
                            <h2 class="mbr-fonts-style mbr-bold mbr-section-title3 display-5">
                                <span>List of users</span>
                            </h2>
                            <p class="mbr-fonts-style text1 mbr-text display-6">View student lists and edit functions for student accounts.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="mbr-col-lg-6 mbr-col-md-10">
                <a href="Assignment.php">
                    <div class="wrap">
                        <div class="ico-wrap">
                            <span class="mbr-iconfont fa-book fa"></span>
                        </div>
                        <div class="text-wrap vcenter">
                            <h2 class="mbr-fonts-style mbr-bold mbr-section-title3 display-5">
                                <span>Assignment</span>
                            </h2>
                            <p class="mbr-fonts-style text1 mbr-text display-6">In here you can upload new assignment for all of your student.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="mbr-col-lg-6 mbr-col-md-10">
                <a href="Games.php">
                    <div class="wrap">
                        <div class="ico-wrap">
                            <span class="mbr-iconfont fa-gamepad fa"></span>
                        </div>
                        <div class="text-wrap vcenter">
                            <h2 class="mbr-fonts-style mbr-bold mbr-section-title3 display-5">
                                <span>Games</span>
                            </h2>
                            <p class="mbr-fonts-style text1 mbr-text display-6">This game will let your student read the content of the file, their mission is to guess the file name.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="mbr-col-lg-6 mbr-col-md-10">
                <a href="AddStudent.php?ref=index.php">
                    <div class="wrap">
                        <div class="ico-wrap">
                            <span class="mbr-iconfont fa-users fa"></span>
                        </div>
                        <div class="text-wrap vcenter">
                            <h2 class="mbr-fonts-style mbr-bold mbr-section-title3 display-5">
                                <span>Add new student</span>
                            </h2>
                            <p class="mbr-fonts-style text1 mbr-text display-6">You can add new student in here or go to list of student first and then use the add function.</p>
                        </div>
                    </div>
                </a>
        </div>
    </div>
      

    <div class="button-container">
        <!-- Button to run the script -->
        <form method="post">
            <input type="submit" name="run_script" value="Restore database">
        </form>
    </div>

    <?php
    if (isset($_POST['run_script'])) {
        // Run the Bash script
        $output = shell_exec('Database/test.sh 2>&1');

        // Display the output of the script
        echo "<pre>$output</pre>";
    }
    ?>

</body>
</html>