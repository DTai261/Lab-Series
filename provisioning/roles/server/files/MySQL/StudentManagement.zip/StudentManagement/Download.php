<?
    session_start();
    $role = ["teacher", "student"];
    if(!isset($_SESSION) or !in_array($_SESSION['role'], $role) or !isset($_GET)){
        header("Location: index.php");
    }
    if($_GET['ref'] === "Games.php" and $_SESSION['role'] === "student")
    $file = $_GET['download'];
    if(!file_exists($file)){
        if($_GET['ref'] === "Assignment.php"){
            header("Location: Assignment.php?msg=download_fail");
            exit();
        }
        if($_GET['ref'] === "Assignment.php"){
            header("Location: Games.php?msg=download_fail");
            exit();
        }
    }

    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
?>