<?
  require_once('dbhelp.php');
  require_once 'config.php';
  session_start();

  if($_SERVER['REQUEST_METHOD'] === "POST"){
    if(!empty($_POST['username']) and !empty($_POST['password'])){
      //prevent SQLi
      $username = mysqli_real_escape_string($db, $_POST['username']);
      $password = mysqli_real_escape_string($db, $_POST['password']);
      $password = hash("sha256", $password);

      $result = get_role($db, $username, $password);

      if($result !== NULL){
        $_SESSION['username'] = $result['username'];
        $_SESSION['fullname'] =  $result['fullname'];
        $_SESSION['role'] =  $result['role'];
        $_SESSION['id'] = get_id($db, $result['username'])['id'];
        $_SESSION['teacher_username'] = get_info($db, $_SESSION['id'])['teacher_username'];
        // echo $_SESSION['id'];
        header("Location: index.php");
      }else{
        $msg_error = "Invalid username or password";
      }

    }else{
      $msg_error = "Invalid username or password";
    }
  }

?>
<!-- HTML -->
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="css/Login.css">
        <style>
          h1{
            text-align: center;
            font-weight:bold;
            margin: 50 auto -70px;
          }
          body {
            background-image: url('assets/background.jpg');
            background-size: cover;
          }
        </style>
    </head>
    <body>
        <h1>Welcome to Students management page!</h1>
        <div class="login-page">
            <div class="form">
                <?
                  if(isset($msg_error)){
                    echo "<p style=\"color: red\">". $msg_error . "</p>";
                  }
                ?>
              <form class="login-form" method="POST" action="#">
                <input type="text" placeholder="username" name="username"/ required>
                <input type="password" placeholder="password" name="password"/ required>
                <button>login</button>
              </form>
            </div>
          </div>
    </body>
</html>

