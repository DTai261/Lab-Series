<?
    function get_id($db, $username){
        $query = "SELECT id, fullname from users where username='$username'";
        $result = $db -> query($query);
        $result = $result -> fetch_assoc();
        return $result;
    }


    function exist_id($db, $id){
        $query = "SELECT username from users where id='$id'";
        $result = $db -> query($query);
        if(!$result){
            return false;
        }
        $result = $result -> fetch_assoc();
        if($result == NULL){
            return false;
        }else{
            return true;
        }
    }  

    //get role by username and password when user login
    function get_role($db, $username, $password){
        $query = "select id, username, role, fullname from users where username = '$username' and password = '$password'";
        $result = $db -> query($query);
        $result = $result -> fetch_assoc();
        return $result;
    }

    function count_student($db, $teacher){
        $teacher = mysqli_escape_string($db, $teacher);
        $query = "select count(username) from students where teacher_username = '$teacher'";
        $result = $db -> query($query);
        if(!$result){
            return 0;
        }
        $result = $result -> fetch_assoc();
        return $result['count(username)'];
    }

    function get_role_by_ID($db, $id){
        $query = "select role from users where id = '$id'";
        $result = $db -> query($query);
        if(!$result){
            return false;
        }
        $result = $result -> fetch_assoc();
        if($result['role'] === "teacher"){
            return true;
        }
        return false;
    }

    //check exist username for add new student function
    function is_exist_username($db, $username){
        $sql = "select * from users where username = '$username'";
        $select = mysqli_query($db, $sql);
        if(mysqli_num_rows($select)) {
            return true;
        }
        return false;
    }

    //check exist username in update function (can user the same username before update)
    function is_exist_username_update($db, $username, $original_username){
        $query = "select username from users where username != '$original_username'";
        $run = mysqli_query($db, $query);
        
        while($row = $run->fetch_assoc()) {
            if($username === $row['username']){
                return true;
            }
        }
        return false;
    }

    function check_password($password){
        $number = preg_match('@[0-9]@', $password);
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        // $specialChars = preg_match('@[^\w]@', $password);
        
        if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase) {
            return false;
        }else{
            return true;
        }
    }

    //check if teacher fill all the information of student
    function check_empty($array){
        if(!empty($array['username']) and !empty($array['fullname']) and !empty($array['password'])
        and !empty($array['confirm_password']) and !empty($array['email']) and !empty($array['phone'])
        and !empty($array['dob']) and !empty($array['gender']) and !empty($array['address'])
        and !empty($array['ID_card']) and !empty($array['class']) and !empty($array['rollnumber'])){
            return true;
        }else{
            return false;
        }
    }

    //check if student fill all the infor of them self
    function check_empty_role_student($array){
        if(!empty($array['password']) and !empty($array['confirm_password']) and !empty($array['email']) 
        and !empty($array['phone']) and !empty($array['dob']) and !empty($array['gender']) 
        and !empty($array['address']) and !empty($array['ID_card']) and !empty($array['class']) 
        and !empty($array['rollnumber'])){
            return true;
        }else{
            return false;
        }
    }

    //check if teacher fill all infor of his/her self
    function check_empty_role_teacher($array){
        if(!empty($array['username']) and !empty($array['fullname']) and !empty($array['password'])
        and !empty($array['confirm_password']) and !empty($array['email']) and !empty($array['phone'])
        and !empty($array['gender'])){
            return true;
        }else{
            return false;
        }
    }

    function insert_student($db,$array, $teacher){
        extract($array);
        $password = hash("sha256", $password);
        $sql_insert_users = "insert into users (username, fullname, role, password, email, phone, gender) values ('$username', '$fullname', '$role', '$password', '$email', '$phone', '$gender')";
        // echo $sql_insert_users;
        // echo $sql_insert_users . "<br><br>";
        $run = mysqli_query($db, $sql_insert_users);
        if(!$run){
            echo "from users table: " .  mysqli_error($db);
        }

        $sql_insert_students = "insert into students values ('$username', '$dob', '$ID_card', '$address', '$rollnumber', '$class', '$teacher')";
        // echo $sql_insert_students;
        $run1 = mysqli_query($db, $sql_insert_students);
        if(!$run1){
            echo "from students table: " .  mysqli_error($db);
        }
    }

    function get_list($db, $id){
        $sql = "select id, username, fullname, email, phone, role from users  where id != '$id' order by role desc";
        $query = mysqli_query($db, $sql);
        $result = array();
        
        if ($query){
            while ($row = mysqli_fetch_assoc($query)){
                $result[] = $row;
            }
        }else{
            echo "Failed to fetch data";
        }
        
        return $result;
    }

    
    function get_info($db, $id){
        if(get_role_by_ID($db, $id)){
            $sql = "SELECT id, username, fullname, role, email, phone, gender from users where id = '$id'";
        }else{
            $sql = "SELECT id, users.username, fullname, role, email, phone, gender, dob, ID_card, address, rollnumber, class, teacher_username from users INNER JOIN students on students.username = users.username where id = '$id'";
        }
        $query = mysqli_query($db, $sql);
        $result = array();
        
        if ($query){
            while ($row = mysqli_fetch_assoc($query)){
                $result[] = $row;
            }
        }else{
            echo "Failed to fetch data";
        }
        return $result[0];
    }

    function delete_student($db, $id, $username){
        $id = mysqli_escape_string($db, $id);

        $query2 = "delete from students where username = '$username'";
        $run2 = mysqli_query($db, $query2);
        if(!$run2){
            echo "can't delete student have username $username". mysqli_error($db);
            echo "-------";
        }

        $query = "delete from users where id = '$id'";
        $run = mysqli_query($db, $query);
        if(!$run){
            echo "can't delete user have id $id " . mysqli_error($db);
            echo "-------";
        }
    }

    function update_student($db, $array, $user){
        extract($array);
        $password = hash("sha256", $password);
        if(isset($array['username']) and isset($array['fullname'])){
            $query_update_users = "UPDATE users SET username = '$username', 
            fullname = '$fullname', password = '$password', email = '$email', 
            phone ='$phone', gender='$gender' WHERE users.id = $id";
        }else{
            $query_update_users = "UPDATE users SET password = '$password', email = '$email', 
            phone ='$phone', gender='$gender' WHERE users.id = $id";
        }
        
        // update table users
        $update_users = mysqli_query($db, $query_update_users);
        if(!$update_users){
            echo "can't update user have id $id". mysqli_error($db);
        }

        //update table students
        $query_update_students = "UPDATE students SET dob = '$dob', ID_card = '$ID_card', 
        address = '$address', rollnumber = '$rollnumber', class = '$class' 
        WHERE students.username = '$username'";
        $update_students = mysqli_query($db, $query_update_students);
        if(!$update_students){
            echo "can't update student have username $username". mysqli_error($db);
        }
        var_dump(get_info($db, $user));
    }
    function update_teacher($db, $array){
        extract($array);
        $password = hash("sha256", $password);
        $query_update_users = "UPDATE users SET username = '$username', fullname = '$fullname', password = '$password', email = '$email', phone ='$phone', gender='$gender' WHERE users.id = $id";
        // echo "--------<br>" . $query_update_users . "---------<br>";
        // update table users
        $update_users = mysqli_query($db, $query_update_users);
        if(!$update_users){
            echo "can't update user have id $id". mysqli_error($db);
        }
    }

    function who_sent_me_message($db, $id){
        $id = mysqli_escape_string($db, $id);
        $query = "SELECT DISTINCT from_user from message where to_user = $id";
        
        $run = mysqli_query($db, $query);
        if(!$run){
            header('Location: index.php');
            exit();
        }
        $result = array();
    
        if ($query){
            while ($row = mysqli_fetch_assoc($run)){
                $result[] = $row;
            }
        }            
        return $result;
    }

    //Modify to get SQL injection
    function get_all_message($db, $id_from, $id_to){
        // $id_from = mysqli_escape_string($db, $id_from);
        // $id_to = mysqli_escape_string($db, $id_to);
        // if(!is_numeric($id_from) or !is_numeric($id_to)){
        //     return NULL;
        // }
        $query = "select * from message where from_user = $id_from and to_user = $id_to UNION 
                  select * from message where from_user = $id_to and to_user = $id_from order by id";
        $run = mysqli_query($db, $query);
        if(!$run){
            return NULL;
        }
        $result = array();
    
        if ($query){
            while ($row = mysqli_fetch_assoc($run)){
                $result[] = $row;
            }
        }            
        return $result;
    }

    function exist_message($db, $id){
        $query = "SELECT id from message where id='$id'";
        $result = $db -> query($query);
        if(!$result){
            return false;
        }
        $result = $result -> fetch_assoc();
        if($result == NULL){
            return false;
        }else{
            return true;
        }
    }  

    function count_unread_message($db, $id_from, $id_to){
        $id_from = mysqli_escape_string($db, $id_from);
        $id_to = mysqli_escape_string($db, $id_to);
        $query = "SELECT COUNT(id) from message where from_user = $id_from and to_user = $id_to and seen = 0";
        $run = mysqli_query($db, $query);
        if($run){
            return ($run -> fetch_assoc()['COUNT(id)']);
        }
    }

    function is_my_message($db, $check_id, $my_id){
        $check_id = mysqli_escape_string($db, $check_id);
        $my_id = mysqli_escape_string($db, $my_id);
        $query = "select id from message where from_user = $my_id";
        $run = mysqli_query($db, $query);
        if(!$run){
            return false;
        }
        while($row = $run->fetch_assoc()) {
            if($$check_id === $row['id']){
                return true;
            }
        }
        return false;
    }
    function delete_message($db, $id){
        $id = mysqli_escape_string($db, $id);
        $query = "delete from message where id = $id";
        $run = mysqli_query($db, $query);
        return $run;
    }
?>
