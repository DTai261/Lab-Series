<?
    require_once('dbhelp.php');
    require_once 'config.php';
    session_start();
    error_reporting(E_ERROR);

    // function SQLi(mysqli $db, string $item): string
    // {
    //     return mysqli_real_escape_string($db, $item);
    // }
    
    if($_SERVER['REQUEST_METHOD'] === "GET"){
        $_SESSION['ref'] = $_GET['ref'];
    }

    if(!isset($_SESSION['role']) and !isset($_SESSION['username'])){
        header("Location: Login.php");
    }

    

    if($_SERVER['REQUEST_METHOD'] === "POST"){
        if(check_empty($_POST)){
            $check = true;
            // find solution for this later
            $_POST['username'] = strtolower(mysqli_real_escape_string($db, $_POST['username']));
            $_POST['fullname'] = ucfirst(mysqli_real_escape_string($db, $_POST['fullname']));
            $_POST['password'] = mysqli_real_escape_string($db, $_POST['password']);
            $_POST['confirm_password'] = mysqli_real_escape_string($db, $_POST['confirm_password']);
            $_POST['email'] = mysqli_real_escape_string($db, $_POST['email']);
            $_POST['phone'] = mysqli_real_escape_string($db, $_POST['phone']);
            $_POST['dob'] = mysqli_real_escape_string($db, $_POST['dob']);
            $_POST['gender'] = mysqli_real_escape_string($db, $_POST['gender']);
            $_POST['address'] = mysqli_real_escape_string($db, $_POST['address']);
            $_POST['ID_card'] = mysqli_real_escape_string($db, $_POST['ID_card']);
            $_POST['class'] = mysqli_real_escape_string($db, $_POST['class']);
            $_POST['rollnumber'] = mysqli_real_escape_string($db, $_POST['rollnumber']);
            $_POST['role'] = "student";

            if(is_exist_username($db, $_POST['username'])){
                $check = false;
                $msg_username = "Username already exist";
            }

            if (!preg_match('#^(?=.{3,10}$)(?![0-9])[a-z0-9_]+$#', $_POST['username'])) {
                $check = false;
                $msg_username = "username can only contain lowercase characters, numbers and must start with a letter";
            } 

            if(!check_password($_POST['password'])){
                $check = false;
                $msg_password = "password must contain lower, upper case, number and special character";
            }

            if($_POST['password'] !== $_POST['confirm_password']){
                $check = false;
                $msg_confirm_pass = "confirm passwoord not match";
            }

            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $check = false;
                $msg_email = "in valid email address";
            }

            if (!preg_match('#[\d]{10}#', $_POST['phone'])) {
                $check = false;
                $msg_phone = "in valid phone number";
            } 

            if($check){
                insert_student($db, $_POST, $_SESSION['username']);
                $msg_success = "add new student success !";
                unset($_POST);
            }

        }else{
            $msg_error = "You must fill in all the information first";
        }
    }

    
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add new Student</title>
    <link rel="stylesheet" href="css/addstudent.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
          body {
            background-image: url('assets/addstudent.jpg');
            background-size: cover;
          }
        </style>
</head>
<body>
    
<div class="container bg-white mt-sm-4 mb-5">
    <div class="d-md-flex flex-md-row">
        <div class="brand text-uppercase h4 font-weight-bold"> <a href="<?=$_SESSION['ref']?>"><span class="fa fa-arrow-left pr-1"></span></a> </div>
        <!-- <div class="ml-auto px-2 pt-1 border rounded search"> <input type="text" placeholder="Search"><span class="fa fa-search text-muted"></span> </div>
        <div class="btn px-4 ml-md-3">Request a demo</div> -->
    </div>
    <div class="wrapper d-flex justify-content-center flex-column px-md-5 px-1">
        <div class="h3 text-center font-weight-bold">Add new Student</div>
        <form action="AddStudent.php" method="POST">
            <div class="row my-4">
                
                <div class="col-md-6"> <label><?if(isset($msg_username)){echo "<p style=\"color: red; font-size:10px;\">". $msg_username . "</p>";}?>User Name</label> <input type="text" placeholder="" name="username" value="<?=$_POST['username']?>" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label>Full name</label> <input type="text" placeholder="" name="fullname" value="<?=$_POST['fullname']?>" required> </div>
            </div>
            <div class="row my-md-4 my-2">
                <div class="col-md-6"> <label><?if(isset($msg_password)){echo "<p style=\"color: red; font-size:10px;\">". $msg_password . "</p>";}?>Password</label> <input type="password" placeholder="" name="password" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label><?if(isset($msg_email)){echo "<p style=\"color: red; font-size:10px;\">". $msg_email . "</p>";}?>Email</label> <input type="email" placeholder="" name="email"value="<?=$_POST['email']?>" required> </div>
            </div>
            <div class="row my-md-4 my-2">
                <div class="col-md-6"> <label><?if(isset($msg_confirm_pass)){echo "<p style=\"color: red; font-size:10px;\">". $msg_confirm_pass . "</p>";}?>Confirm password</label> <input type="password" placeholder="" name="confirm_password" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label>Phone</label> <?if(isset($msg_phone)){echo "<p style=\"color: red; font-size:10px;\">". $msg_phone . "</p>";}?> <input type="tel" placeholder="" name="phone" value="<?=$_POST['phone']?>" required> </div>
            </div>
            <div class="row my-md-4 my-2">
                <div class="col-md-6"> <label>Date of Birth</label> <input type="date" name="dob" value="<?=$_POST['dob']?>" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label>Gender</label> <select name="gender" id="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select> </div>
            </div> 
            <div class="row my-md-4 my-2">
                <div class="col-md-6"> <label>Address</label> <input type="text" placeholder="" name="address" value="<?=$_POST['address']?>" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label>ID card</label> <input type="text" placeholder="" name="ID_card" value="<?=$_POST['ID_card']?>" required> </div>
            </div>
            <div class="row my-md-4 my-2">
                <div class="col-md-6"> <label>Class</label> <input type="text" placeholder="" name="class" value="<?=$_POST['class']?>" required> </div>
                <div class="col-md-6 pt-md-0 pt-4"> <label>Roll number</label> <input type="text" placeholder="" name="rollnumber" value="<?=$_POST['rollnumber']?>" required> </div>
            </div>
            <?
                if(isset($msg_error)){
                    echo "<p style=\"color: red\">". $msg_error . "</p>";
                }
                if(isset($msg_success)){
                    echo "<p style=\"color: green\">". $msg_success . "</p>";
                }
            ?>
            <div class="d-flex justify-content-end"> <button class="btn" type="submit">Submit</button> </div>
        </form>
    </div>
</div>
</body>
</html>