<?

    require_once('dbhelp.php');
    require_once 'config.php';
    session_start();
    if(!isset($_SESSION)){
        header('Location: index.php');
        exit();
    }
    
    
    if($_SERVER['REQUEST_METHOD'] === "POST"){
        if(empty($_POST['message'])){
            header('Location: '. $_POST['ref']);
            exit();
        }
        if(!isset($_POST['from']) and !isset($_POST['to'])){
            header("Location: index.php");
            exit();
        }else{
            if(!exist_id($db, $_POST['from']) or !exist_id($db, $_POST['to'])){
                header("Location: " . $_POST['ref']);
                exit();
            }
        }
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $from = mysqli_escape_string($db, $_POST['from']);
        $to = mysqli_escape_string($db, $_POST['to']);
        $message = mysqli_escape_string($db, $_POST['message']);
        $timestamp = date('Y-m-d H:i:s');
        if(isset($_POST['seen']) and exist_message($db, $_POST['seen'])){
            $seen = mysqli_escape_string($db, $_POST['seen']);
            $count = mysqli_escape_string($db, $_POST['count']);
            //rever order of to and from here because we update mess from another user
            $query_update_state_message =  "update message SET seen = 1 where from_user = $to and to_user = $from and seen = 0 order by id DESC LIMIT $count";
            // echo $query_update_state_message . "<br>";
            $run = mysqli_query($db, $query_update_state_message);
            // var_dump($run);
        }
        $query_insert_message = "INSERT INTO message (from_user, to_user, text, timestamp, seen) VALUES ('$from', '$to', '$message', '$timestamp', '0')";
        $run = mysqli_query($db, $query_insert_message);
        if(!$run){
            $msg = "send_fail";
        }else{
            $msg = "send_success";
        }
        $_POST['ref'] = preg_replace("#&msg=send_.*$#", "" , $_POST['ref']);
        header("Location: " . $_POST['ref'] . "&msg=" . $msg);
    }

    if($_SERVER['REQUEST_METHOD'] === "GET"){
        if(!isset($_GET['delete']) or !is_my_message($db, $_GET['delete'], $_SESSION['id'])){
            header("Location: Profile.php?id=" . $_SESSION['id']);
        }
        if(delete_message($db, $_GET['delete'])){
            header("Location: Profile.php?id=" . $_SESSION['id']);
        }
    }
?>