<?

    require_once('dbhelp.php');
    require_once 'config.php';
    session_start();
    
    if(!isset($_SESSION['role']) and !isset($_SESSION['username'])){
        header("Location: Login.php");
    }
    if(isset($_GET['ref'])){
        $_SESSION['ref'] = $_GET['ref'];
    }
    $id = $_SESSION['id'];
    $edit = false;
    $editmore = false;
    if(isset($_GET)){
        $user = get_info($db, $_GET['id']);
    }
    
    if($_SERVER['REQUEST_METHOD'] === "GET" or $_SERVER['REQUEST_METHOD'] === "POST"){
        if(!exist_id($db, $_GET['id'])){
            header("Location: ListStudents.php");
        }
        if(isset($_GET['edit']) and $_GET['edit'] === "true" and ($_SESSION['role'] === "teacher" or $id === $user['id'])){
            $edit = true;
            if($_SESSION['role'] === "teacher"){
                $editmore = true;
            }
        }
    }

    if($_SERVER['REQUEST_METHOD'] === "POST"){
        // var_dump($user);
        // $check = $_SESSION['role'] === "teacher" ? check_empty($_POST) : check_empty_role_student(($_POST));
        if($_SESSION['role'] === "teacher"){
            if($user['role'] === "teacher"){
                $check = check_empty_role_teacher($_POST);
            }else{
                $check = check_empty_role_student($_POST);
            }
        }else{
            $check = check_empty_role_student($_POST);
            // echo 'student123123';
        }

        if($check){
            if($_SESSION['role'] === "teacher"){
                $_POST['username'] = strtolower(mysqli_real_escape_string($db, $_POST['username']));
                $_POST['fullname'] = ucfirst(mysqli_real_escape_string($db, $_POST['fullname']));
                
                if (!preg_match('#^(?=.{3,20}$)(?![0-9])[a-z0-9_]+$#', $_POST['username'])) {
                    $check = false;
                    $msg_username = "username can only contain lowercase characters, numbers and must start with a letter";
                } 
                elseif(is_exist_username_update($db, $_POST['username'], $user['username'])){
                    $check = false;
                    $msg_username = "username already exist";
                }
            }else{
                $_POST['username'] = strtolower(mysqli_real_escape_string($db, $user['username']));
            }
            $_POST['password'] = mysqli_real_escape_string($db, $_POST['password']);
            $_POST['confirm_password'] = mysqli_real_escape_string($db, $_POST['confirm_password']);
            $_POST['email'] = mysqli_real_escape_string($db, $_POST['email']);
            $_POST['phone'] = mysqli_real_escape_string($db, $_POST['phone']);
            // $_POST['gender'] = mysqli_real_escape_string($db, $_POST['gender']);
            if($user['role'] === "student"){
                $_POST['dob'] = mysqli_real_escape_string($db, $_POST['dob']);
                $_POST['address'] = mysqli_real_escape_string($db, $_POST['address']);
                $_POST['ID_card'] = mysqli_real_escape_string($db, $_POST['ID_card']);
                $_POST['class'] = mysqli_real_escape_string($db, $_POST['class']);
                $_POST['rollnumber'] = mysqli_real_escape_string($db, $_POST['rollnumber']);
                $_POST['role'] = "student";
            }
            

            if(!check_password($_POST['password'])){
                $check = false;
                $msg_password = "password must contain lower, upper case, number and special character";
            }

            if($_POST['password'] !== $_POST['confirm_password']){
                $check = false;
                $msg_confirm_pass = "confirm passwoord not match";
            }

            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $check = false;
                $msg_email = "in valid email address";
            }

            if (!preg_match('#[\d]{10}#', $_POST['phone'])) {
                $check = false;
                $msg_phone = "in valid phone number";
            } 

            if($check){
                $_POST['id'] = $user['id'];
                if($user['role'] === "student"){
                    // var_dump($user);
                    update_student($db, $_POST, $_GET['id']);
                }elseif($user['role'] === "teacher"){
                    update_teacher($db, $_POST);
                }
                unset($_POST);
                header("Location: Profile.php?id=" . $user['id'] . "&msg=success");
            }

        }else{
            $msg_error = "You must fill in all the information first";
        }
    }
    //get current URL
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
    $url = "https://";   
    else  
        $url = "http://";   
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   

    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI'];    
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- for chat -->
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="css/test1.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="js/test1.js"></script>
</head>
<body style="background-image: url('assets/profile.jpg'); background-size: cover;">

<div class="container rounded bg-white mt-5 mb-5">
    <div class="row">
        <!-- picture area -->
        <div class="col-md-3 border-right">
            <h2>
                <?if($id !== $user['id']):?>
                    <a class="nav-link link display-7" style="float:left;" href="<?=$_SESSION['ref']?>">
                        <span class="mbr-iconfont fa-arrow-left fa"></span>
                    </a>
                <?endif?>
                <a style="display:block;width:20px" class="nav-link link display-7" href=".">
                    <span class="mbr-iconfont fa-home fa"></span>
                </a>
            </h2>
            <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" 
                <?if($user['gender'] === "Male"):?>
                    src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg">
                <?else:?>
                    src="https://static.vecteezy.com/system/resources/previews/002/002/297/large_2x/beautiful-woman-avatar-character-icon-free-vector.jpg">
                <?endif?>
                <span class="font-weight-bold"><?=htmlspecialchars($user['username'])?></span>
                <span class="text-black-50"><?=htmlspecialchars($user['email'])?></span>
                <span> </span>
            </div>
        </div>
        <!-- end of picture area -->

        <!-- Detail area -->
        <!-- student layout -->
    <?if($user['role'] === "student"):?>
        <div class="col-md-5  border-right">
            <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Profile</h4>
                    </div>
                <form action="Profile.php?id=<?=$_GET['id']?>&edit=true" method="post" id="update">
                    <?if($editmore):?>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <label class="labels">Username</label>
                                <?if(isset($msg_username)){echo "<p style=\"color: red; font-size:10px;\">". $msg_username . "</p>";}?>
                                <input type="text" class="form-control" name="username" value="<?=$user['username']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                        </div>
                    <?endif?>
                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label class="labels">Full name</label>
                            <input type="text" class="form-control" name="fullname" value="<?=$user['fullname']?>" <?if(!$editmore){echo 'disabled="disabled"';}?>>
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Class</label>
                            <input type="text" class="form-control" name="class" value="<?=$user['class']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Date of birth</label>
                            <input type="date" class="form-control" name="dob" value="<?=$user['dob']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Gender</label>
                            <?if(!$edit):?>
                                <input type="text" class="form-control" name="gender" value="<?=$user['gender']?>"disabled="disabled">
                            <?else:?>
                                <select name="gender" class="form-control" id="gender" > 
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            <?endif?>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <?if($edit):?>
                            <div class="col-md-12">
                                <label class="labels">Password</label>
                                <?if(isset($msg_password)){echo "<p style=\"color: red; font-size:10px;\">". $msg_password . "</p>";}?>
                                <input type="password" class="form-control" name="password" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                            <div class="col-md-12">
                                <label class="labels">Confirm password</label>
                                <?if(isset($msg_confirm_pass)){echo "<p style=\"color: red; font-size:10px;\">". $msg_confirm_pass . "</p>";}?>
                                <input type="password" class="form-control" name="confirm_password" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                            <div class="col-md-12">
                                <label class="labels">Email</label>
                                <?if(isset($msg_email)){echo "<p style=\"color: red; font-size:10px;\">". $msg_email . "</p>";}?>
                                <input type="text" class="form-control" name="email" value="<?=$user['email']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                        <?endif?>
                        <div class="col-md-12">
                            <label class="labels">Phone Number</label>
                            <?if(isset($msg_phone)){echo "<p style=\"color: red; font-size:10px;\">". $msg_phone . "</p>";}?>
                            <input type="text" class="form-control" name="phone" value="<?=$user['phone']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                        </div>
                        <div class="col-md-12"><label class="labels">Address</label><input type="text" class="form-control" name="address" value="<?=$user['address']?>" <?if(!$edit){echo 'disabled="disabled"';}?>></div>
                        <div class="col-md-12"><label class="labels">ID card</label><input type="text" class="form-control" name="ID_card" value="<?=$user['ID_card']?>" <?if(!$edit){echo 'disabled="disabled"';}?>></div>
                        <div class="col-md-12"><label class="labels">Roll number</label><input type="text" class="form-control" name="rollnumber" value="<?=$user['rollnumber']?>" <?if(!$edit){echo 'disabled="disabled"';}?>></div>
                        <?
                            if(isset($msg_error)){
                                echo "<p style=\"color: red\">". $msg_error . "</p>";
                            }
                        ?>
                    </div>
                </form>
                <?
                    if(isset($_GET['msg']) and $_GET['msg'] === "success"){
                        echo "<p style=\"color: green\">Update success !</p>";
                    }
                ?>
                <?if($_SESSION['role'] === "teacher" or $id === $user['id']):?>
                    <div class="mt-5 text-center">
                        <?if(!$edit):?>
                            <input class="btn btn-success" onclick="window.location = 'Profile.php?id=<?=$user['id']?>&edit=true'" type="button" value="Edit profile"/>
                        <?else:?>
                            <div class="mt-5 text-center">
                                <button class="btn btn-primary profile-button" type="submit" form="update" value="Submit">Submit</button>
                            </div>
                            <form action="Profile.php" method="GET">
                                <input type="hidden" name="id" value="<?=$_GET['id']?>">
                                <input class="btn btn-success" type="submit" value="Cancel">
                            </form>
                        <?endif?>
                    </div>
                <?endif?>
            </div>
        </div>
    <!-- teacher layout -->
    <?else:?>
        <div class="col-md-5  border-right">
            <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Profile</h4>
                    </div>
                <form action="Profile.php?id=<?=$_GET['id']?>&edit=true" method="post" id="update">
                    <?if($editmore):?>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <label class="labels">Username</label>
                                <?if(isset($msg_username)){echo "<p style=\"color: red; font-size:10px;\">". $msg_username . "</p>";}?>
                                <input type="text" class="form-control" name="username" value="<?=$user['username']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                        </div>
                    <?endif?>
                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label class="labels">Full name</label>
                            <input type="text" class="form-control" name="fullname" value="<?=$user['fullname']?>" <?if(!$editmore){echo 'disabled="disabled"';}?>>
                        </div>
                        <div class="col-md-6">
                            <label class="labels">Gender</label>
                            <?if(!$edit):?>
                                <input type="text" class="form-control" name="gender" value="<?=$user['gender']?>"disabled="disabled">
                            <?else:?>
                                <select name="gender" class="form-control" id="gender" > 
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            <?endif?>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <?if($edit):?>
                            <div class="col-md-12">
                                <label class="labels">Password</label>
                                <?if(isset($msg_password)){echo "<p style=\"color: red; font-size:10px;\">". $msg_password . "</p>";}?>
                                <input type="password" class="form-control" name="password" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                            <div class="col-md-12">
                                <label class="labels">Confirm password</label>
                                <?if(isset($msg_confirm_pass)){echo "<p style=\"color: red; font-size:10px;\">". $msg_confirm_pass . "</p>";}?>
                                <input type="password" class="form-control" name="confirm_password" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                            <div class="col-md-12">
                                <label class="labels">Email</label>
                                <?if(isset($msg_email)){echo "<p style=\"color: red; font-size:10px;\">". $msg_email . "</p>";}?>
                                <input type="text" class="form-control" name="email" value="<?=$user['email']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                            </div>
                        <?endif?>
                        <div class="col-md-12">
                            <label class="labels">Phone Number</label>
                            <?if(isset($msg_phone)){echo "<p style=\"color: red; font-size:10px;\">". $msg_phone . "</p>";}?>
                            <input type="text" class="form-control" name="phone" value="<?=$user['phone']?>" <?if(!$edit){echo 'disabled="disabled"';}?>>
                        </div>
                        <?
                            if(isset($msg_error)){
                                echo "<p style=\"color: red\">". $msg_error . "</p>";
                            }
                        ?>
                    </div>
                </form>
                <?
                    if(isset($_GET['msg']) and $_GET['msg'] === "success"){
                        echo "<p style=\"color: green\">Update success !</p>";
                    }
                ?>
                <?if($_SESSION['role'] === "teacher" and $user['role'] === "student"):?>
                    <div class="mt-5 text-center">
                        <?if(!$edit):?>
                            <input class="btn btn-success" onclick="window.location = 'Profile.php?id=<?=$user['id']?>&edit=true'" type="button" value="Edit profile"/>
                        <?else:?>
                            <div class="mt-5 text-center">
                                <button class="btn btn-primary profile-button" type="submit" form="update" value="Submit">Submit</button>
                            </div>
                            <form action="Profile.php" method="GET">
                                <input type="hidden" name="id" value="<?=$_GET['id']?>">
                                <input class="btn btn-success" type="submit" value="Cancel">
                            </form>
                        <?endif?>
                    </div>
                <?endif?>
            </div>
        </div>
        <!-- https://cdn.imgbin.com/9/23/13/imgbin-teacher-student-education-tutor-faculty-teacher-yMTi457hmAaneAQem2tWtygJ3.jpg -->
    <?endif?>
        <!-- end of detail area -->

        <!-- Chat area begin -->
        <div class="col-md-4">
            <?if($id !== $user['id']):?>
                <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center experience"><span>Leave a message</span></div><br>
                    <div class="col-md-12">
                        <form action="MessageHandler.php" method="post">
                            <input type="hidden" name="from" value="<?=$_SESSION['id']?>">
                            <input type="hidden" name="to" value="<?=$user['id']?>">
                            <input type="hidden" name="ref" value="<?=$url?>">
                            <input type="text" class="form-control" placeholder="Leave a message here" name="message"><br>
                            <input type="submit" class="form-control" value="Send">
                        </form>
                    </div> <br>
                </div>
                <?if(isset($_GET['msg']) and $_GET['msg'] === "send_success"):?>
                    <p style="color: green">send message success</p>
                <?elseif(isset($_GET['msg']) and $_GET['msg'] === "send_fail"):?>
                    <p style="color: red">send message fail</p>
                <?endif?>
            <?else:?>
                <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center experience"><span>Your message: </span></div><br>
                </div>
            <?endif?>
            <!-- chat small from here -->
            <?if($_GET['id'] === $_SESSION['id']):?>
                <!-- if list_sender = null -->
                <!-- $sender['from_user'] -->
                <?$list_sender = who_sent_me_message($db, $_SESSION['id']); $i = 0;
                    foreach($list_sender as $sender){
                    $sender_id = $sender['from_user'];
                    $all_message = get_all_message($db, $sender_id, $_SESSION['id']);
                    // var_dump($all_message);  
                    ?>
                    
                <script>
                    $(document).on('click', '.icon_close<?=$i?>', function (e) {
                        //$(this).parent().parent().parent().parent().remove();
                        $("#chat_window_<?=$i?>" ).remove();
                    });
                </script>
            <div class="">
                <div class="" id="chat_window_<?=$i?>" style="margin-left:5px;">
                    <div class="col-xs-12 col-md-12">
                        <div class="panel panel-default" style="width: 300px;">
                            <div class="panel-heading top-bar">
                                <div class="col-md-8 col-xs-8">
                                    <?$count_unread = count_unread_message($db, $sender_id, $_SESSION['id'])?>
                                    <?if($count_unread === '0'):?>
                                        <h3 class="panel-title"><?=get_info($db, $sender_id)['username']?><span></span></h3>
                                    <?else:?>
                                        <h3 class="panel-title"><?=get_info($db, $sender_id)['username']?>&emsp;<span class="badge bg-danger float-end"><?=$count_unread?></span></h3>
                                    <?endif?>
                                </div>
                                <div class="col-md-4 col-xs-4" style="text-align: right;">
                                    <a data-toggle="collapse" href="#collapseExample"><span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a>
                                    <a href="#"><span class="glyphicon glyphicon-remove icon_close<?=$i?>" data-id="chat_window_<?=$i?>"></span></a>
                                </div>
                            </div>
                            <div class="collapse panel-body msg_container_base" id="collapseExample" style="overflow-y: scroll;overscroll-behavior-y: contain;scroll-snap-type: y proximity;">
                                <!-- chat start in here -->
                    
                                <?foreach($all_message as $message){
                                    if($message['from_user'] === $_SESSION['id']):?>
                                    <div class="row msg_container base_sent">
                                        <div class="col-md-10 col-xs-10">
                                            <div class="messages msg_sent">
                                                <p><?=htmlspecialchars($message['text'])?></p>
                                                <time datetime="test"><?=$message['timestamp']?>
                                                
                                                    <a href="   "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                    <a href="MessageHandler.php?delete=<?=$message['id']?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                </time>
                                            </div>
                                        </div>
                                        <!-- avt of user -->
                                        <div class="col-md-2 col-xs-2 avatar">
                                            <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">
                                        </div>
                                    </div>
                                <?else:?>
                                <div class="row msg_container base_receive">
                                    <div class="col-md-2 col-xs-2 avatar">
                                        <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">
                                    </div>
                                    <div class="col-md-10 col-xs-10">
                                        <div class="messages msg_receive">
                                            <p><?=htmlspecialchars($message['text'])?></p>
                                            <time datetime="2009-11-13T20:00"><?=$message['timestamp']?>
                                            </time>
                                        </div>
                                    </div>
                                </div>
                                <?endif?>
                                <?}?>
                                <!-- chat end here -->
                            </div>
                            <div class="panel-footer">
                                <div class="input-group">
                                    <form action="MessageHandler.php" method="post" id="send">
                                        <input type="hidden" name="from" value="<?=$_SESSION['id']?>">
                                        <input type="hidden" name="to" value="<?=$sender['from_user']?>">
                                        <input type="hidden" name="seen" value="<?=$message['id']?>">
                                        <input type="hidden" name="count" value="<?=$count_unread?>">
                                        <input type="hidden" name="ref" value="<?=$url?>">
                                        <input  style="width: 80%; float: left;" id="btn-input" type="text" name="message" class="form-control input-sm chat_input" placeholder="Type your message here..." required />
                                        <span  style="float: left;">
                                            <input type="submit" value="send" class="btn btn-primary btn-sm" id="btn-chat">
                                        </span>
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
                    <?$i++;}?>
            <?endif?>
        </div>
        <!-- end of chat area -->
    </div>
</div>
</div>
</div>
</body>
</html>
<!-- 
^(?=.{8,20}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$
 └─────┬────┘└───┬──┘└─────┬─────┘└─────┬─────┘ └───┬───┘
       │         │         │            │           no _ or . at the end
       │         │         │            │
       │         │         │            allowed characters
       │         │         │
       │         │         no __ or _. or ._ or .. inside
       │         │
       │         no _ or . at the beginning
       │
       username is 8-20 characters long 
-->